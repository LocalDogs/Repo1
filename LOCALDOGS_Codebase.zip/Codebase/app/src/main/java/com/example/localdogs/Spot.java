package com.example.localdogs;

public class Spot {
    public String name;
    public String city;
    public String url;
    public int id;

    public Spot() {

    }

    public Spot(String name, String city, String url) {
        this.name = name;
        this.city = city;
        this.url = url;
    }
}
